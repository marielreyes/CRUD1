import { Component, ComponentFactoryResolver, OnInit } from '@angular/core';
import { ActivatedRoute, Route, Router } from '@angular/router';
@Component({
  selector: 'app-view-detail',
  templateUrl: './view-detail.component.html',
  styleUrls: ['./view-detail.component.css']
})
export class ViewDetailComponent implements OnInit {

  user: any;
constructor(private route: ActivatedRoute) { 
  // const user = route.snapshot.data;

  }

  ngOnInit(): void {
    console.log('router', this.route.snapshot.queryParams);

    this.user = this.route.snapshot.queryParams
  }

}

import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { CommonService } from '../common.service';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {
  title = 'CRUD';
  allUser: any;
  isEdit= false;
  userObj={
    name:'',
    mobile: '',
    email: '',
    id: ''
  }
  isSubmitted: boolean = false;


  exform: FormGroup | any;

  constructor(private commonService:CommonService) { }

  ngOnInit(){
    this.getLatestUser()

    this.exform = new FormGroup ({
      'name' : new FormControl(null, Validators.required),
      'mobile' : new FormControl(null, [Validators.required, Validators.pattern('')]),
      'email' : new FormControl(null, [Validators.required, Validators.email])
    })
    console.log("form", this.exform)
    
  }

  addUser(formObj: any) {
    console.log('form', this.exform)
    console.log('name', this.name)
     if(!this.exform.invalid){
      this.commonService.createUser(this.exform.value).subscribe((response)=>{
        console.log('response', response)
        this.getLatestUser();
      })
     }
    
    console.log('exform', this.exform)


  }

  getLatestUser() {
    this.commonService.getAllUser().subscribe((response)=>{
      this.allUser = response
    })
  }

  editUser(user: any) {
    this.isEdit = true;
    this.userObj = user;

  }

  deleteUser(user: any) {
    this.commonService.deleteUser(user).subscribe(()=>{
      this.getLatestUser();
    })
  }

  updateUser(){
    this.isEdit = !this.isEdit;
    this.commonService.updateUser(this.userObj).subscribe(()=>{
      this.getLatestUser();
    })
  }

  get name(){
    return this.exform.get('name');
  }

  get mobile(){
    return this.exform.get('mobile');
  }

  get email(){
    return this.exform.get('email');
  }

}
